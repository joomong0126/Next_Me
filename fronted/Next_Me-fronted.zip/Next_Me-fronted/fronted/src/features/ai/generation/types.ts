export interface UserProfile {
  name: string;
  currentStatus: string[];
  targetRoles: string[];
}

