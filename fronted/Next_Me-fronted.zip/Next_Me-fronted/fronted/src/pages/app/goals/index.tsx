import { GoalsDashboard } from '@/features/profile/goals';

export default function GoalsPage() {
  return <GoalsDashboard />;
}

