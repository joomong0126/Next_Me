# Shared Config

Place application-wide configuration (API endpoints, feature flags, environment mappings) in this directory.

Remove this file if configuration assets move elsewhere.

