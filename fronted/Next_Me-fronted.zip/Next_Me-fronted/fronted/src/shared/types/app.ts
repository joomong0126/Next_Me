export type AppState = 'intro' | 'login' | 'onboarding' | 'app';

export type AppPage = 'assistant' | 'career-generator' | 'projects' | 'skills' | 'goals' | 'settings';

